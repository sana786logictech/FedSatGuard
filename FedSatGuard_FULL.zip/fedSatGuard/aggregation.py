
import numpy as np

def aggregate(updates, trust):
    w = np.array(trust)
    w = w / (np.sum(w) + 1e-9)
    return np.sum(updates * w[:, None], axis=0)
